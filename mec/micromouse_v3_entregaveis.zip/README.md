# Micromouse – Entregáveis CAD (versão final v4)

Esta é a **versão final do modelo do robô**, aprovada pela equipe. Ela parte do arquivo da equipe e não reconstrói o projeto: as posições dos motores, das rodas e dos sensores e o contorno de 120 × 100 mm do chassi foram preservados.

## Conteúdo
| Arquivo | Descrição |
|---|---|
| `micromouse_montagem_v4_pcb_clipes_bateria_inferior.step` | Montagem completa |
| `peca_segundo_andar_v4.step` / `segundo_andar_v4.stl` | 2º andar (peça para impressão) |
| `peca_espacadores_35mm_parafusos.step` / `espacador_35mm.stl` | Espaçadores de 35 mm e parafusos |
| `peca_bateria_74x33x20_referencia.step` | Bateria (volume de referência) |
| `peca_pcb_100x100_referencia.step` | PCB (volume de referência) |
| `vista_*.png` | Vistas isométrica, superior, inferior (bateria), lateral (folgas) e explodida |

## Alterações, motivo e benefício
| # | Alteração | Por que foi feita | Como ajuda o projeto final |
|---|---|---|---|
| 1 | Eixo das rodas centralizado em X = 60, com os motores reposicionados | O robô batia na parede nas curvas (ângulo de 61°) | Raio de giro máximo de 72 mm: gira dentro da célula de 180 mm com 12 mm de folga |
| 2 | Bateria 74 × 33 × 20 suspensa sob o 2º andar, no sentido do comprimento | A bateria ocupava a base, no espaço da mecânica | Peso baixo e centralizado (melhor estabilidade) e base livre para motores e sensores |
| 3 | Dois rasgos de 3 × 59 mm para abraçadeiras de nylon, com bordas arredondadas (R0,5) | Prender a bateria sem encaixe que a pressione ou deforme | Fixação firme, que não corta a abraçadeira; a bateria sai para manutenção e os fios ficam acessíveis |
| 4 | Espaçadores de 25 para 35 mm (2º andar 10 mm mais alto) | Criar altura para a bateria de 20 mm | Folga de 3,45–3,95 mm até as pontas dos parafusos e de 15 mm até a base, sem interferência |
| 5 | Rebaixos de Ø6,2 × 2,2 mm na face superior do 2º andar | As cabeças dos parafusos M3 encostavam na PCB | Cabeças embutidas: nada toca a placa |
| 6 | PCB elevada 8 mm sobre 6 apoios e presa por 6 clipes de encaixe | Não parafusar a PCB nem apoiá-la nos espaçadores | Montagem e remoção sem ferramenta, e vão de 8 mm para passar e soldar os fios por baixo |
| 7 | Berço antigo da bateria removido da base | A bateria mudou de lugar | Menos peso e espaço livre na base |

## Medidas finais
- Comprimento 120 mm; largura 100 mm (102,9 mm com os clipes).
- Altura do chão ao topo da PCB: 63,65 mm. Vão livre sob a base: 9,05 mm.
- Malhas STL verificadas como fechadas (prontas para impressão).

## Pontos em aberto
- A esfera do modelo tem 3/8" (9,525 mm), acima do limite de 9 mm; o suporte deve ser adaptado ao diâmetro escolhido.
- O clipe traseiro da PCB fica na frente do USB-C do ESP32.
- Espessura da PCB assumida em 1,6 mm. Motores e sensores não estão modelados como peças.

**Issue fechada:** #56 (CAD e Documentação CAD)
