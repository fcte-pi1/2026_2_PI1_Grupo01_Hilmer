# Fiação – Micromouse (montagem final v4)

**Objetivo:** validar a integração da estrutura (chassi, 2º andar e PCB) com toda a parte de hardware e energia, antes da montagem física.

## O que as imagens mostram
- Posição real dos módulos na PCB 100 × 100: ESP32, MPU6050, DRV8833, INA226 e 3 buck converters.
- Trajeto dos chicotes da bateria, dos motores, dos encoders e dos 3 sensores ToF (frente e diagonais) até a PCB.
- Os fios sobem pelos rasgos e pelas laterais do 2º andar e correm no vão de 8 mm sob a PCB, onde são soldados.
- Caminho de energia: bateria → INA226 → chave liga/desliga → bucks.

| Arquivo | Vista |
|---|---|
| `fiacao_pcb_real_isometrica.png` | Visão geral |
| `fiacao_pcb_real_vista_superior.png` | Trajeto dos chicotes sob a PCB (raio-X) |
| `fiacao_pcb_real_lateral.png` | Chicotes no vão de 8 mm |
| `fiacao_pcb_real_detalhe_vao.png` | Detalhe do vão sob a PCB |

## Observações
- As imagens são ilustrativas: confirme o comprimento final de cada fio na montagem, com 30–40 mm de folga.
- O suporte traseiro é vazado e não tem sensor.
- O clipe traseiro da PCB fica na frente do USB-C do ESP32; verifique o acesso ao cabo.

**Issues fechadas:** #286, #290
